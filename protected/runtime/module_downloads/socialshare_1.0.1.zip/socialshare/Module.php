<?php

namespace app\modules\socialshare;
class Module extends \humhub\components\Module
{
    
}
