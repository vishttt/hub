## Description

Socialshare module allows you to share your post on other social networks like Linkedin, Twitter, Facebook with backlink to the original post.

__Author:__ radu-stanescu  
__Author website:__ [securityhub.io](https://securityhub.io)