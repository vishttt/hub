<?php
return array (
  'Doesn\'t belong to space' => 'Ne concerne pas l\'espace',
  'Offensive' => 'Choquant',
  'Spam' => 'Spam',
);
