<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Gérer les <strong>contenus signalés</strong>',
  'Reported posts' => 'Contenus signalés',
  'Why do you want to report this post?' => 'Pourquoi voulez-vous signaler ce contenu ?',
  'by :displayName' => 'par :displayName',
  'created by :displayName' => 'créé par :displayName',
);
