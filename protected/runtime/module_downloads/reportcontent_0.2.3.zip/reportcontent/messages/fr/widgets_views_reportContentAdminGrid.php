<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Confirmer</strong> la suppression de ce contenu',
  '<strong>Confirm</strong> report deletion' => '<strong>Confirmer</strong> le signalement de ce contenu',
  'Cancel' => 'Annuler',
  'Content' => 'Contenu',
  'Delete' => 'Supprimer',
  'Delete post' => 'Supprimer le contenu',
  'Delete report' => 'Supprimer le signalement',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Voulez-vous vraiment supprimer ce contenu ? Tous les "j\'aime" et les commentaires seront perdus !',
  'Do you really want to delete this report?' => 'Voulez-vous vraiment supprimer ce signalement ?',
  'Reason' => 'Raison',
  'Reporter' => 'Signaler',
  'There are no reported posts.' => 'Il n\'y a pas de contenus signalés.',
);
