<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Управление <strong>репортами</strong>',
  'Reported posts' => 'Репорты',
  'Why do you want to report this post?' => 'Почему вы хотите написать этот репорт?',
  'by :displayName' => '  :displayName',
  'created by :displayName' => 'создано :displayName',
);
