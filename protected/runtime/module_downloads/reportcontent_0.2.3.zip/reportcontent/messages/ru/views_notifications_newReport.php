<?php
return array (
  'An user has reported your post as offensive.' => 'Пользователь счел ваш пост оскорбительным.',
  'An user has reported your post as spam.' => 'Пользователь отметил ваш пост как спам.',
  'An user has reported your post for not belonging to the space.' => 'Пользователь отметил ваш пост несоответствующим данному пространству.',
);
