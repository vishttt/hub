<?php
return array (
  'Here you can manage reported users posts.' => 'Her kan du administrere anmeldte bruger opslag.',
);
