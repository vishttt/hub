<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Bekræft</strong> sletning af opslag',
  '<strong>Confirm</strong> report deletion' => '<strong>Bekræft</strong> sletning af anmeldelse',
  'Cancel' => 'Afbryd',
  'Content' => 'Indhold',
  'Delete' => 'Slet',
  'Delete post' => 'Slet opslag',
  'Delete report' => 'Slet anmeldelse',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Vil du virkelig slette dette opslag? All syntes godt om og kommentarer bliver tabt.',
  'Do you really want to delete this report?' => 'Vil du virkelig slette denne anmeldelse?',
  'Reason' => 'Grundlag',
  'Reporter' => 'Anmelder',
  'There are no reported posts.' => 'Der er ingen rapporterede opslag',
);
