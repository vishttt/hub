<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% har anmeldt %contentTitle% som angribende.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% har anmeldt %contentTitle% som spam.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% har anmeldt %contentTitle% fordi det ikke hører til på siden.',
);
