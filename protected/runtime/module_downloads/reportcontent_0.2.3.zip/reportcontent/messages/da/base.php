<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Administrer <strong>anmeldte opslag</strong>',
  'Reported posts' => 'Anmeldte opslag',
  'Why do you want to report this post?' => 'Hvorfor vil du anmelde dette opslag?',
  'by :displayName' => 'af :displayName',
  'created by :displayName' => 'Lavet af :displayName',
);
