<?php
return array (
  'Doesn\'t belong to space' => 'Não está relacionado ao espaço',
  'Offensive' => 'Ofensivo',
  'Spam' => 'Spam',
);
