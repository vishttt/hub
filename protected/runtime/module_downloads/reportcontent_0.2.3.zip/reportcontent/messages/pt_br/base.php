<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Gerenciar <strong>posts reportados</strong>',
  'Reported posts' => 'Posts reportados',
  'Why do you want to report this post?' => 'Por que você quer denunciar essa postagem?',
  'by :displayName' => 'por :displayName',
  'created by :displayName' => 'criado por :displayName',
);
