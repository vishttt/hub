<?php
return array (
  'Manage <strong>reported posts</strong>' => '<strong>Gerapporteerde</strong> berichten',
  'Reported posts' => 'Gerapporteerde berichten',
  'Why do you want to report this post?' => 'Waarom wil je dit bericht rapporteren?',
  'by :displayName' => 'door :displayname',
  'created by :displayName' => 'gemaakt door :displayname',
);
