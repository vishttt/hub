<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Mesaj</strong> silmeyi onayla',
  '<strong>Confirm</strong> report deletion' => '<strong>Rapor</strong> silmeyi onayla',
  'Cancel' => 'İptal',
  'Content' => 'İçerik',
  'Delete' => 'Sil',
  'Delete post' => 'Mesajı sil',
  'Delete report' => 'Raporu Sil',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Bu yazıyı silmek istiyor musunuz? Yorumlar ve beğeniler silinecektir!',
  'Do you really want to delete this report?' => 'Bu raporu silmek istiyor musunuz?',
  'Reason' => 'Neden',
  'Reporter' => 'Tarafından',
  'There are no reported posts.' => 'Rapor edilen mesaj bulunamadı.',
);
