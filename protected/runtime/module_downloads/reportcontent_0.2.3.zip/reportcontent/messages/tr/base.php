<?php
return array (
  'Manage <strong>reported posts</strong>' => '<strong>Raporlanan</strong> mesajlar',
  'Reported posts' => 'Raporlar',
  'Why do you want to report this post?' => 'Neden raporlamak istiyorsun?',
  'by :displayName' => ':displayName tarafından',
  'created by :displayName' => 'oluşturan :displayName',
);
