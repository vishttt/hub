<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% hat den Beitrag %contentTitle% als beleidigend gemeldet.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% hat den Beitrag %contentTitle% als Spam gemeldet.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% hat den Beitrag %contentTitle% gemeldet, weil er nicht in diesen Space gehört.',
);
