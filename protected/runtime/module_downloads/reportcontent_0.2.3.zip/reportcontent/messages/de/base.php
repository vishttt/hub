<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Bearbeite <strong>gemeldete Beiträge</strong>',
  'Reported posts' => 'Melde den Beitrag',
  'Why do you want to report this post?' => 'Warum möchtest Du den Beitrag melden?',
  'by :displayName' => 'von :displayName',
  'created by :displayName' => 'erstellt von :displayName',
);
