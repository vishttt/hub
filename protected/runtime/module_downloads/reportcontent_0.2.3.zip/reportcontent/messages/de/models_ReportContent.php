<?php
return array (
  'Doesn\'t belong to space' => 'Gehört nicht zum Space',
  'Offensive' => 'beleidigend',
  'Spam' => 'Spam',
);
