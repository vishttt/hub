<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Bestätigung</strong> der Löschung des Beitrages',
  '<strong>Confirm</strong> report deletion' => '<strong>Bestätigung</strong> der Löschung der Meldung',
  'Cancel' => 'Abbrechen',
  'Content' => 'Inhalt',
  'Delete' => 'Löschen',
  'Delete post' => 'Beitrag löschen',
  'Delete report' => 'Meldung löschen',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Möchtest du diesen Beitrag wirklich löschen? Alle Likes und Kommentare werden unwiederbringlich entfernt.',
  'Do you really want to delete this report?' => 'Möchtest du die Meldung wirklich löschen?',
  'Reason' => 'Grund',
  'Reporter' => 'Melder',
  'There are no reported posts.' => 'Keine gemeldeten Beiträge.',
);
