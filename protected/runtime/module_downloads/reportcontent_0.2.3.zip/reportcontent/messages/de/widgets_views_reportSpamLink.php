<?php
return array (
  'Does not belong here' => 'Gehört nicht in diesen Space',
  'Help Us Understand What\'s Happening' => 'Helf uns zu verstehen, was vorgegangen ist',
  'It\'s offensive' => 'Ist beleidigend',
  'It\'s spam' => 'Ist Spam',
  'Report post' => 'Beitrag melden',
  'Submit' => 'Absenden',
);
