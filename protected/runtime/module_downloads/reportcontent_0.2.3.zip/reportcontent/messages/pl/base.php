<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Zarządzaj <strong>zgłoszonymi treściami</strong>',
  'Reported posts' => 'Zgłoszone treści',
  'Why do you want to report this post?' => 'Dlaczego chcesz zgłosić tę treść?',
  'by :displayName' => 'przez :displayName',
  'created by :displayName' => 'utworzone przez :displayName',
);
