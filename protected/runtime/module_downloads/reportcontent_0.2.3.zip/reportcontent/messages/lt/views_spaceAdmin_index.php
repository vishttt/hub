<?php
return array (
  'Here you can manage reported posts for this space.' => 'Čia Jūs galite valdyti šios erdvės pranešimus apie skelbimus.',
);
