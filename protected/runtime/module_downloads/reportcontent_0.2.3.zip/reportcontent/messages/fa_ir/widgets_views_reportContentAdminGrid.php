<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>تاييد حذف پست</strong>',
  '<strong>Confirm</strong> report deletion' => '<strong>تاييد گزارش حذف پست</strong>',
  'Cancel' => 'لغو',
  'Content' => 'محتوا',
  'Delete' => 'حذف',
  'Delete post' => 'حذف پست',
  'Delete report' => 'حذف گزارش',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'واقعا مي خواهيد اين مطلب را حذف كنيد؟',
  'Do you really want to delete this report?' => 'واقعا مي خواهيد اين گزارش را حذف كنيد؟',
  'Reason' => 'علت',
  'Reporter' => 'گزارش‌کننده',
  'There are no reported posts.' => 'هيچ مطلب گزارش شده اي موجود نيست',
);
