<?php
return array (
  'Loading...' => 'lädt...',
);
