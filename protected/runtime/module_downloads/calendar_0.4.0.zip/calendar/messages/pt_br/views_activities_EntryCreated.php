<?php
return array (
  '%displayName% created a new %contentTitle%.' => '%displayName% criou um novo %contentTitle%.',
);
