<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Próximos</strong> eventos',
);
