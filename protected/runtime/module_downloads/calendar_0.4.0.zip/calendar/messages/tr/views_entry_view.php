<?php
return array (
  'Attend' => 'Katılıyorum',
  'Decline' => 'Katılmıyorum',
  'Edit event' => 'Etkinlik düzenle',
  'Maybe' => 'Belki',
);
