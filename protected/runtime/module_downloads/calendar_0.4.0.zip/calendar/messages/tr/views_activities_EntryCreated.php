<?php
return array (
  '%displayName% created a new %contentTitle%.' => '%displayName% yeni bir %contentTitle% içerik oluşturdu.',
);
