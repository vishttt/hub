<?php
return array (
  'Attend' => 'Chci se zúčastnit',
  'Decline' => 'Nechci se zúčastnit',
  'Edit event' => 'Změnit událost',
  'Maybe' => 'Možná',
);
