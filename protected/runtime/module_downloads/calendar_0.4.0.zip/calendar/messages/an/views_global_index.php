<?php
return array (
  '<strong>Filter</strong> events' => '',
  '<strong>Select</strong> calendars' => '',
  'Already responded' => '',
  'Followed spaces' => '',
  'Followed users' => '',
  'I´m attending' => '',
  'My events' => '',
  'My profile' => 'O mío perfil',
  'My spaces' => '',
  'Not responded yet' => '',
);
