<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>次回</strong> 次回のイベント',
);
