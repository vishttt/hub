<?php
return array (
  ':count attending' => ':count biorący udział',
  ':count declined' => ':count nie biorący udziału',
  ':count maybe' => ':count może biorący udział',
  'Participants:' => 'Uczestnicy: ',
);
