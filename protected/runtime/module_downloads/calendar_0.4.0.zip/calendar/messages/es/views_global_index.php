<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filtrar</strong> eventos',
  '<strong>Select</strong> calendars' => '<strong>Elegir</strong> calendario',
  'Already responded' => 'Ya respondido',
  'Followed spaces' => 'Espacios seguidos',
  'Followed users' => 'Usuarios seguidos',
  'I´m attending' => 'Asistiré',
  'My events' => 'Mis eventos',
  'My profile' => 'Mi perfil',
  'My spaces' => 'Mis espacios',
  'Not responded yet' => 'No respondido aún',
);
