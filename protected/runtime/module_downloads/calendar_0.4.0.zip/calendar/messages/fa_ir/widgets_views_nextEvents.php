<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>نزدیک</strong> رویدادهای',
);
