<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Artėjantys</strong> renginiai',
);
