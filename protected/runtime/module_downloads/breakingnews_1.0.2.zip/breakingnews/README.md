## Description

Popups a breaking news lightbox on dashboard. The message can be set by all admins
in markdown syntax language.

v1.1.1
    - Enhanced markdown editor

__Module website:__ <https://github.com/humhub/humhub-modules-breakingnews>
__Author:__ luke, andystrobel  
__Author website:__ [humhub.org](http://humhub.org)

## Changelog

<https://github.com/humhub/humhub-modules-breakingnews/commits/master>

## Bugtracker

<https://github.com/humhub/humhub-modules-breakingnews/issues>
