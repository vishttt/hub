<?php

return [
    #'humhub_root' => '...',
    'modules' => ['breakingnews'],
    'fixtures' => ['default']
];



