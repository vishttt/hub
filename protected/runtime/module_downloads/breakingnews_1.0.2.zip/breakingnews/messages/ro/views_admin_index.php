<?php
return array (
  'Back to modules' => 'Înapoi la module',
  'Breaking News Configuration' => 'Configurare Știri de Ultimă oră',
  'Note: You can use markdown syntax.' => 'Notă: Poți folosi sintaxa markdown.',
  'Save' => 'Salvează',
);
