<?php
return array (
  'Back to modules' => 'Modüllere geri dön',
  'Breaking News Configuration' => 'Son Dakika Haberleri Yapılandırma',
  'Note: You can use markdown syntax.' => 'Not: Markdown söz dizimini kullanabilirsiniz.',
  'Save' => 'Kaydet',
);
