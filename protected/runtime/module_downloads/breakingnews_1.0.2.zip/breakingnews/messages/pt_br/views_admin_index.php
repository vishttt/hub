<?php
return array (
  'Back to modules' => 'Voltar para módulos',
  'Breaking News Configuration' => 'Configuração Breaking News',
  'Note: You can use markdown syntax.' => 'Nota: Você pode usar a sintaxe markdown.',
  'Save' => 'Salvar',
);
