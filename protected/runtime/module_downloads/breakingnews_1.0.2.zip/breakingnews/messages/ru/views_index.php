<?php
return array (
  'Close' => 'Закрыть',
);
