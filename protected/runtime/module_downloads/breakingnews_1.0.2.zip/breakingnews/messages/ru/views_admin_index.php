<?php
return array (
  'Back to modules' => 'Назад к модулям',
  'Breaking News Configuration' => 'Настройки новостей',
  'Note: You can use markdown syntax.' => 'К сведению: Вы можете использовать синтаксис markdown',
  'Save' => 'Сохранить',
);
