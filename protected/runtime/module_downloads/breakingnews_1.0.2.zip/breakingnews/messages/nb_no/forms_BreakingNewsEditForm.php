<?php
return array (
  'Active' => 'Aktiv',
  'Mark as unseen for all users' => 'Marker som usett for alle brukere',
  'Message' => 'Melding',
  'Title' => 'Tittel',
);
