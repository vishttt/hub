<?php
return array (
  'Close' => 'إغلاق',
);
