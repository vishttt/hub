<?php
return array (
  'Active' => 'Attivo',
  'Mark as unseen for all users' => 'Marca come non visto per tutti gli utenti',
  'Message' => 'Messaggio',
  'Title' => 'Titolo',
);
