<?php
return array (
  'Back to modules' => 'Atgal į modulius',
  'Breaking News Configuration' => 'Karščiausiu naujienu konfigūracija',
  'Note: You can use markdown syntax.' => 'Jūs galite naudoti formatuoti su \'markdown\' ',
  'Save' => 'Išsaugoti',
);
