<?php
return array (
  'Active' => 'Aktyvus',
  'Mark as unseen for all users' => 'Pažymėti kaip neperskaitytus visiems vartotojams',
  'Message' => 'Žinutė',
  'Title' => 'Pavadinimas',
);
