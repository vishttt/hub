<?php
return array (
  'Active' => 'アクティブ',
  'Mark as unseen for all users' => 'すべてのユーザーに不可視としてマーク',
  'Message' => 'メッセージ',
  'Title' => 'タイトル',
);
