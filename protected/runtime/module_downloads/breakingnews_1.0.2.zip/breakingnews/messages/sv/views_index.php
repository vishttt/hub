<?php
return array (
  'Close' => 'Stäng',
);
