<?php
return array (
  'Active' => 'Activado',
  'Mark as unseen for all users' => 'Marcar como invisível para todos os utilizadores',
  'Message' => 'Mensagem',
  'Title' => 'Título',
);
