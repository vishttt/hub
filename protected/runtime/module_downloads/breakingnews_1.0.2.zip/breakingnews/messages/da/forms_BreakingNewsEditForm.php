<?php
return array (
  'Active' => 'Aktiv',
  'Mark as unseen for all users' => 'Markér som uset for alle brugere',
  'Message' => 'Besked',
  'Title' => 'Titel',
);
