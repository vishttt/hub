<?php
return array (
  'Back to modules' => 'Terug naar modules',
  'Breaking News Configuration' => 'Breaking News Configuratie',
  'Note: You can use markdown syntax.' => 'Let op: Je kunt markdown syntax gebruiken',
  'Save' => 'Enregistrer',
);
