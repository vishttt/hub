<?php
return array (
  'Back to modules' => 'Zurück zu den Modulen',
  'Breaking News Configuration' => 'Konfiguration Eilmeldungen',
  'Note: You can use markdown syntax.' => 'Hinweis: Du kannst die Markdown Sytax verwenden.
(Weitere Infos unter http://www.markdown.de)',
  'Save' => 'Speichern',
);
