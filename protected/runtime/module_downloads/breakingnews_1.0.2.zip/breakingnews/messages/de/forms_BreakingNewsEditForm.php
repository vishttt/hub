<?php
return array (
  'Active' => 'Aktiv',
  'Mark as unseen for all users' => 'Für alle Nutzer als ungelesen markieren',
  'Message' => 'Nachricht',
  'Title' => 'Titel',
);
