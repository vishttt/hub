<?php
return array (
  'Close' => 'بستن',
);
