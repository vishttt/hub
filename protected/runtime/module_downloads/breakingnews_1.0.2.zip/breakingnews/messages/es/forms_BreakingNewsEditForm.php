<?php
return array (
  'Active' => 'Activa',
  'Mark as unseen for all users' => 'Marcar como no vista para todos los usuarios',
  'Message' => 'Mensaje',
  'Title' => 'Título',
);
