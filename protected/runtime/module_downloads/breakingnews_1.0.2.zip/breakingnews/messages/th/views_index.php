<?php
return array (
  'Close' => 'ปิด',
);
