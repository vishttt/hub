<?php
return array (
  'Close' => '',
);
