<?php
return array (
  'Back to modules' => 'Torna al mòduls',
  'Breaking News Configuration' => 'Configuració de les Notícies d\'Última Hora',
  'Note: You can use markdown syntax.' => 'Nota: pots utilitzar la sintaxi markdown.',
  'Save' => 'Desa',
);
