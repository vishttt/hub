<?php
return array (
  'Active' => 'Aktywuj',
  'Mark as unseen for all users' => 'Oznacz jako nieprzeczytaną dla wszystkich użytkowników.',
  'Message' => 'Wiadomość',
  'Title' => 'Tytuł',
);
