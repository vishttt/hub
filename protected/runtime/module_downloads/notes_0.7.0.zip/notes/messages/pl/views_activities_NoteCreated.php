<?php
return array (
  '{userName} created a new note {noteName}.' => '{userName} utworzył nową notatkę {noteName}.',
);
