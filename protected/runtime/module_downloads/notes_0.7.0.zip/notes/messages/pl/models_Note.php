<?php
return array (
  'Could not get note content!' => 'Nie można wczytać zawartości notatki! ',
  'Could not get note users! ' => 'Nie można wczytać notatki użytkowników! ',
  'Note' => 'Notatka ',
);
