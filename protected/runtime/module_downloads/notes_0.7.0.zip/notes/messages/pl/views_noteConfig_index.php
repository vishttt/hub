<?php
return array (
  'API Connection successful!' => 'Z powodzeniem połączono z API!',
  'Back to modules' => 'Powrót do modułów',
  'Could not connect to API!' => 'Nie można połączyć się z API!',
  'Current Status:' => 'Obecny status: ',
  'Notes Module Configuration' => 'Konfiguracja modułu notatek',
  'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => 'Proszę przeczytaj dokumentację modułu pod adresem /protected/modules/notes/docs/install.txt aby uzyskać więcej szczegółów!',
  'Save & Test' => 'Zapisz i testuj',
  'The notes module needs a etherpad server up and running!' => 'Moduł notatek wymaga pracującego serwera etherpad! ',
);
