<?php
return array (
  'Etherpad API Key' => 'API ключ Etherpad',
  'URL to Etherpad' => 'Путь к Etherpad (URL)',
);
