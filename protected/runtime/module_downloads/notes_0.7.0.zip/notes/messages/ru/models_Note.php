<?php
return array (
  'Could not get note content!' => 'Не могу прочить содерджимое заметки!',
  'Could not get note users! ' => 'Не удалось получить заметки пользователей!',
  'Note' => 'Заметка',
);
