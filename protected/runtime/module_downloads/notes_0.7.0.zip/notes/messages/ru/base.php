<?php
return array (
  'Notes' => 'Заметки',
);
