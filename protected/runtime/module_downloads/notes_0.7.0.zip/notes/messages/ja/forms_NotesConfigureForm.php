<?php
return array (
  'Etherpad API Key' => 'EtherpadのAPIキー',
  'URL to Etherpad' => 'EtherpadへのURL',
);
