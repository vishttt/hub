<?php
return array (
  '{userName} created a new note {noteName}.' => '{userName}さんは新しいノート {noteName} を作成しました。',
);
