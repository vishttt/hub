<?php
return array (
  'Could not get note content!' => 'ノートの内容を取得できませんでした！',
  'Could not get note users! ' => 'ノートのユーザーを取得できませんでした!',
  'Note' => 'メモ',
);
