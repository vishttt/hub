<?php
return array (
  'Save and close' => 'Gem og luk',
);
