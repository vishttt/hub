<?php
return array (
  'Title of your new note' => 'Titelen på din nye note',
);
