<?php
return array (
  '{userName} created a new note and assigned you.' => '{userName} tilføjede en ny note og har tilføjet dig.',
);
