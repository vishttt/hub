<?php
return array (
  'Open note' => 'Åbn note',
);
