<?php
return array (
  'Save and close' => 'Speichern und schließen',
);
