<?php
return array (
  'Notes' => 'Notizen',
);
