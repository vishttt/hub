<?php
return array (
  'API Connection successful!' => 'API Verbindung erfolgreich!',
  'Back to modules' => 'Zurück zu den Modulen',
  'Could not connect to API!' => 'Konnte nicht mit der API verbinden!',
  'Current Status:' => 'Aktueller Status:',
  'Notes Module Configuration' => 'Konfiguration Notizmodul',
  'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => 'Bitte für weitere Details die Moduldokumentation unter /protected/modules/notes/docs/install.txt lesen!',
  'Save & Test' => 'Speichern & Testen',
  'The notes module needs a etherpad server up and running!' => 'Das Notizmodul benötigt einen intallierten und laufenden Etherpad Server!',
);
