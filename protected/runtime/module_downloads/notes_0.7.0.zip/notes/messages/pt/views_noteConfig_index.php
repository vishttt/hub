<?php
return array (
  'API Connection successful!' => '',
  'Back to modules' => 'Voltar para os módulos',
  'Could not connect to API!' => '',
  'Current Status:' => '',
  'Notes Module Configuration' => '',
  'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => '',
  'Save & Test' => '',
  'The notes module needs a etherpad server up and running!' => '',
);
