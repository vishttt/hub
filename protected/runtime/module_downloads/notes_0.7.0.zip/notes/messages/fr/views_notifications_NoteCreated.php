<?php
return array (
  '{userName} created a new note and assigned you.' => '{userName} a créé une nouvelle note et vous l\'a assignée.',
);
