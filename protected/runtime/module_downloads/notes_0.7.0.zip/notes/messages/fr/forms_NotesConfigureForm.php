<?php
return array (
  'Etherpad API Key' => 'Clé de l\'API Etherpad',
  'URL to Etherpad' => 'URL Etherpad',
);
