<?php
return array (
  '{userName} has worked on the note {noteName}.' => '{userName} a travaillé sur la note {noteName}.',
);
