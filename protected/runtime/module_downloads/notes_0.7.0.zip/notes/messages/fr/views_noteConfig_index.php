<?php
return array (
  'API Connection successful!' => 'Connexion à l\'API avec succès!',
  'Back to modules' => 'Retour aux modules',
  'Could not connect to API!' => 'Impossible de se connecter à l\'API!',
  'Current Status:' => 'Status courant:',
  'Notes Module Configuration' => 'Configuration du module Notes',
  'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => 'Veuillez lire la documentation du module sous /protected/modules/notes/docs/install.txt pour plus de détails',
  'Save & Test' => 'Enregistrer & Tester',
  'The notes module needs a etherpad server up and running!' => 'Le module de notes requiert un serveur etherpad actif!',
);
