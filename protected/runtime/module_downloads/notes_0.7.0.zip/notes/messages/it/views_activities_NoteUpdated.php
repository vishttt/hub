<?php
return array (
  '{userName} has worked on the note {noteName}.' => '{userName} ha lavorato sulla nota {noteName}.',
);
