<?php
return array (
  'Open note' => 'Apri nota',
);
