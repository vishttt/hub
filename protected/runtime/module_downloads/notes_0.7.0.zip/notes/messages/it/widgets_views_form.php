<?php
return array (
  'Title of your new note' => 'Titolo della tua nuova nota',
);
