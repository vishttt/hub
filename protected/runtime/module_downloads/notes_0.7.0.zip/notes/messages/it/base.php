<?php
return array (
  'Notes' => 'Note',
);
