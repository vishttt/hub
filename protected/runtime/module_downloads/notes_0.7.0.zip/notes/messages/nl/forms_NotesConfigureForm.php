<?php
return array (
  'Etherpad API Key' => 'Etherpad API sleutel',
  'URL to Etherpad' => 'URL naar Etherpad',
);
