<?php
return array (
  'Save and close' => 'Bewaar en sluiten',
);
