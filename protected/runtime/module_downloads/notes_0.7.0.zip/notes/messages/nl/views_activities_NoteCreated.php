<?php
return array (
  '{userName} created a new note {noteName}.' => '{userName} heeft nieuwe notitie {noteName} gemaakt.',
);
