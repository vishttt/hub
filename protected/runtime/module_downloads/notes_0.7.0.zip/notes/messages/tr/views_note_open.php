<?php
return array (
  'Save and close' => 'Kaydet ve kapat',
);
