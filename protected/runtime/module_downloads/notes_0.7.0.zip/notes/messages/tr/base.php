<?php
return array (
  'Notes' => 'Notlar',
);
