<?php
return array (
  'Open note' => 'Notu aç',
);
