<?php
return array (
  '{userName} created a new note {noteName}.' => '{userName} creó una nueva nota {noteName}.',
);
