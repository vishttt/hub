<?php
return array (
  'Etherpad API Key' => 'Etherpad API raktas',
  'URL to Etherpad' => 'URL Etherpad',
);
