<?php
return array (
  'API Connection successful!' => 'API prijungimas pavyko!',
  'Back to modules' => 'Atgal į modulius',
  'Could not connect to API!' => 'Nepavyko prisijungti prie API!',
  'Current Status:' => 'Dabartinis statusas:',
  'Notes Module Configuration' => 'Pastabų modulio konfigūracija',
  'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => 'Norint gauti papildomos informacijos, prašome perskaityti modulio dokumentus, esančius /protected/modules/notes/docs/install.txt',
  'Save & Test' => 'Išsaugoti ir išbandyti',
  'The notes module needs a etherpad server up and running!' => 'Pastabų modulis reikalauja, kad veiktų EtherPad serveris!',
);
