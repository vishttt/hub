<?php
return array (
  'API Connection successful!' => 'اتصال موفق API!',
  'Back to modules' => 'بازگشت‌ به ماژول‌‌ها',
  'Could not connect to API!' => 'اتصال به API برقرار نشد!',
  'Current Status:' => 'وضعیت کنونی:',
  'Notes Module Configuration' => 'تنظیمات ماژول یادداشت',
  'Please read the module documentation under /protected/modules/notes/docs/install.txt for more details!' => 'لطفا برای جزئیات بیشتر مستند ماژول را در /protected/modules/notes/docs/install.txt مطالعه کنید!',
  'Save & Test' => 'ذخیره و آزمایش',
  'The notes module needs a etherpad server up and running!' => 'ماژول یادداشت نیاز به یک سرور در حال کار etherpad دارد!',
);
