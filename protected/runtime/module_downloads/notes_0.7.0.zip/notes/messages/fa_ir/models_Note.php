<?php
return array (
  'Could not get note content!' => 'محتوای یادداشت گرفته‌نشد!',
  'Could not get note users! ' => 'نتوانستيم نوشته هاي كاربر را نمايش دهيم',
  'Note' => 'یادداشت',
);
