<?php
return array (
  'Notes' => 'نوشته‌ها',
);
