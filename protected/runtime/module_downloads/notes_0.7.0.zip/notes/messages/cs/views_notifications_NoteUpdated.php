<?php
return array (
  '{userName} has worked on the note {spaceName}.' => '{userName} provedl(a) změnu v poznámce {spaceName}.',
);
