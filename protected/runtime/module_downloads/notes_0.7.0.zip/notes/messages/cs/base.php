<?php
return array (
  'Notes' => 'Poznámky',
);
