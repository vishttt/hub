<?php
return array (
  'Open note' => 'Otevřít poznámku',
);
