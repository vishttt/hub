<?php
return array (
  '{userName} created a new note and assigned you.' => '{userName} napsal(a) novou poznámku a přiřadil(a) vás k ní.',
);
