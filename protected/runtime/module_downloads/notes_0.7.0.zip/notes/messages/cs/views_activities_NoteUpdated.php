<?php
return array (
  '{userName} has worked on the note {noteName}.' => '{userName} provedl(a) změnu v poznámce {noteName}.',
);
