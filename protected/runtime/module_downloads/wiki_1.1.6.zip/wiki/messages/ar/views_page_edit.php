<?php
return array (
  '<strong>Create</strong> new page' => '<strong>بدء</strong> صفحة جديدة',
  '<strong>Edit</strong> page' => '<strong>تعديل</strong> صفحة',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'الرجاء إدخال عنوان صفحة ويكي او الوصلة المؤدية لها مثلاُ http://example.com',
  'New page title' => 'عنوان صفحة جديد',
  'Page content' => 'محتويات الصفحة',
  'Save' => 'حفظ',
);
