<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Crea</strong> una nuova pagina',
  '<strong>Edit</strong> page' => '<strong>Modifica</strong> pagina',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'Inserisci un nome per la pagina wiki o un url (es. http://example.com)',
  'New page title' => 'Titolo nuova pagina',
  'Page content' => 'Contenuto pagina',
  'Save' => 'Salva',
);
