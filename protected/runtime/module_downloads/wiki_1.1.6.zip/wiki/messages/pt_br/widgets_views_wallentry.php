<?php
return array (
  'Open wiki page...' => 'Abrir página wiki...',
);
