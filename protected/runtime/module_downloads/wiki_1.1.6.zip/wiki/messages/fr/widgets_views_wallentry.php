<?php
return array (
  'Open wiki page...' => 'Ouvir la page wiki...',
);
